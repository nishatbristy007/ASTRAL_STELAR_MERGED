package phylonet.coalescent;

public class CannotResolveException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5345180960017149729L;

	public CannotResolveException(String v) {
		super(v);
	}

}
